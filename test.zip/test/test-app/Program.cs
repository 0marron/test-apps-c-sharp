﻿using System;

namespace native_arr_app
{
    class Program
    {

        static void Main(string[] args)
        {
      
            var native_arr = new int[6, 6] { 
                                        {11,12,13,14,15,16},
                                        {17,18,19,20,21,22},
                                        {23,24,25,26,27,28},
                                        {29,30,31,32,33,34},
                                        {35,36,37,38,39,40},
                                        {41,42,43,44,45,46}
                                     };
            View(native_arr);

            var length  = native_arr.GetLength(0);
         
            for (int x = 0; x < length/2; x++)
            {
                for (int y = 0; y < (length+1)/2; y++)
                {
                    int tmp = native_arr[x, y];
                    native_arr[x, y] = native_arr[y, (length - 1) - x];                                
                    native_arr[y, (length - 1) - x] = native_arr[(length - 1) - x, (length - 1) - y]; 
                    native_arr[(length - 1) - x, (length - 1) - y] = native_arr[(length - 1) - y, x];
                    native_arr[(length - 1) - y, x] = tmp;
                }
            }

            View(native_arr);
          
        }


        static void View(int[,] arr)
        {
            string picture = String.Empty;
            for (int x = 0; x <= arr.GetLength(0)- 1; x++)
            {
                for (int y = 0; y <= arr.GetLength(0) - 1; y++)
                {
                    picture += arr[x ,y] + " ";
                }
                picture +="\n";
            }
            Console.WriteLine(picture);
        }
    }
}