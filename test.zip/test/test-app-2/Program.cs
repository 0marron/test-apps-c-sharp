﻿using System;
using System.IO;
using System.Text;

namespace native_arr_app
{
    class Program
    {
        
        static void Main(string[] args)
        {

            int[] filter_arr = new int[10000];
            int filter_arr_counter = 0;

            int arr_counter = 0;
       
            var arr = CreateRandomArray();

            bool CR = false;
            bool LF = false;


            const int chunkSize = 1; // read the file by chunks of 1KB
            using (var file = File.OpenRead("DATA.txt"))
            {
                int bytesRead;
                var buffer = new byte[chunkSize];
                string line = null;
                while ((bytesRead = file.Read(buffer, 0, buffer.Length)) > 0)
                {
                    if(buffer[0] == 13)
                    {
                        CR = true;
                    }
                    if (buffer[0] == 10)
                    {
                        LF = true;
                    }
                    if (CR && !LF)
                    {
                        continue;
                    }

                    if (CR && LF)
                    {
                        LF = false; CR = false;
                        //
                        for (; arr_counter < arr.Length; arr_counter++)
                        {
                            if (arr[arr_counter] < Int32.Parse(line))
                            {
                                File.AppendAllText("TEMP.txt", arr[arr_counter].ToString() + "\r\n");
                            }
                            if (arr[arr_counter] == Int32.Parse(line))
                            {
                                File.AppendAllText("TEMP.txt", arr[arr_counter].ToString() + "\r\n");
                            }
                           
                            if (arr[arr_counter] > Int32.Parse(line))
                            {
                                break;
                            }
                        }
                        File.AppendAllText("TEMP.txt", line + "\r\n");
                        //
                        line = null;
                        continue;
                        // Конец строки
                    }
                    line += new ASCIIEncoding().GetString(buffer);

                    if( !Array.Exists(arr, element => element != Int32.Parse(line)))
                    {
                        filter_arr[filter_arr_counter] = Int32.Parse(line);
                        filter_arr_counter++;
                    }

                    Console.WriteLine(bytesRead.ToString());
            
                }
                for (; arr_counter < arr.Length; arr_counter++)
                {   
                    //фильтрация
                    filter_arr[filter_arr_counter] = arr[arr_counter];
                    filter_arr_counter++;
                    //фильтрация

                    File.AppendAllText("TEMP.txt", arr[arr_counter].ToString() + "\r\n");
                }
            }


        }

        static private int[] CreateRandomArray()
        {
            int[] arr = new int[3] { 5,7,9};
            // int[] arr = new int[10000];
            //for (int i = 0; i < 10000; i++)
            //{
            //    int rnd = new Random().Next(1, 999999);
            //    arr[i] = rnd;
            //}
            //Array.Sort(arr);
            return arr; 
        }
    }
}